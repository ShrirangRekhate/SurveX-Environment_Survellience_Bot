# Rescue Bot Dashboard

A comprehensive web-based dashboard for controlling and monitoring your ESP32-based Rescue Bot.

## Features

- Real-time control of robot movement (forward, backward, left, right, stop)
- Speed control with adjustable slider
- Live video feed from robot camera
- 3D visualization of robot position using MPU6050 data
- Real-time sensor monitoring:
  - Temperature sensor
  - Smoke sensor
  - Ultrasonic sensors (front, left, right)
- WebSocket-based communication with ESP32

## Project Structure

- `src/components`: React components for the dashboard UI
- `src/hooks`: Custom hooks for data management and WebSocket communication
- `src/lib`: Helper functions and ESP32 integration guide

## How to Use

1. Launch the web application
2. Connect to your ESP32 by entering its IP address
3. The dashboard will display the sensor data and allow you to control the robot

## ESP32 Integration

The dashboard communicates with your ESP32 via WebSockets. Refer to the `src/lib/esp32-integration.ts` file for a detailed integration guide and example code for your ESP32.

## Technologies Used

- React
- TypeScript
- Tailwind CSS
- Three.js for 3D visualization
- WebSockets for real-time communication

## Project Setup

```sh
# Install dependencies
npm install

# Start development server
npm run dev
```

## Building for Production

```sh
npm run build
```

## Customization

You can customize the dashboard by modifying the components in the `src/components` directory. The 3D model can be customized in the `BotCanvas.tsx` file.
