import React, { useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import * as THREE from "three";

interface BotCanvasProps {
  rotation: {
    x: number;
    y: number;
    z: number;
  };
  ultrasonic: {
    front: number;
    left: number;
    right: number;
  };
}

// Robot model component
const RobotModel = ({
  rotation,
  ultrasonic,
}: {
  rotation: BotCanvasProps["rotation"];
  ultrasonic: BotCanvasProps["ultrasonic"];
}) => {
  const robotRef = useRef<THREE.Group>(null);

  // Update robot rotation based on MPU6050 data
  useFrame(() => {
    if (robotRef.current) {
      // Convert degrees to radians
      //robotRef.current.rotation.x = THREE.MathUtils.degToRad(rotation.x);
      robotRef.current.rotation.y = THREE.MathUtils.degToRad(rotation.y);
     // robotRef.current.rotation.z = THREE.MathUtils.degToRad(rotation.z);
    }
  });

  // Convert ultrasonic sensor readings (in cm) with default value = 100 if not available,
  // and clamp them between 5 cm and 100 cm.
  const frontDistance = Math.min(Math.max(ultrasonic.front || 200, 5), 200);
  const leftDistance = Math.min(Math.max(ultrasonic.left || 200, 5), 200);
  const rightDistance = Math.min(Math.max(ultrasonic.right || 200, 5), 200);

  // Conversion factor to adjust cm to 3D units.
  const scaleFactor = 20; // Adjust this factor as needed

  // Bot dimensions in scene units (derived from robot body geometry)
  const botDepth = 1.1; // half of the robot's front length (e.g. half of 2.2)
  const botWidth = 0.75; // half of the robot's width (e.g. half of 1.5)

  // Calculate wall positions so that they only move along one axis relative to the bot:
  // - Front wall moves along the Z-axis only.
  const frontWallZ = -(botDepth + frontDistance / scaleFactor);
  // - Left wall moves along the X-axis only.
  const leftWallX = -(botWidth + leftDistance / scaleFactor);
  // - Right wall moves along the X-axis only.
  const rightWallX = botWidth + rightDistance / scaleFactor;

  // Calculate color intensity based on distance (closer = more intense red)
  const getFillColor = (distance: number) => {
    if (distance < 20) return new THREE.Color(1, 0, 0);
    if (distance < 50) return new THREE.Color(0.8, 0, 0);
    return new THREE.Color(0.6, 0, 0);
  };

  // Calculate opacity based on distance (closer = more opaque)
  const getOpacity = (distance: number) => {
    if (distance < 20) return 0.8;
    if (distance < 50) return 0.6;
    return 0.4;
  };

  return (
    <group ref={robotRef}>
      {/* Robot body */}
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[1.5, 0.4, 2.2]} />
        <meshStandardMaterial
          color="#33C3F0"
          emissive="#33C3F0"
          emissiveIntensity={0.3}
          metalness={0.8}
          roughness={0.2}
        />
      </mesh>

      {/* Wheels */}
      <mesh
        position={[-0.8, -0.2, 0.7]}
        rotation={[Math.PI / 2, 0, Math.PI / 2]}
      >
        <cylinderGeometry args={[0.3, 0.3, 0.15, 16]} />
        <meshStandardMaterial color="#222" metalness={0.6} roughness={0.4} />
      </mesh>
      <mesh
        position={[0.8, -0.2, 0.7]}
        rotation={[Math.PI / 2, 0, Math.PI / 2]}
      >
        <cylinderGeometry args={[0.3, 0.3, 0.15, 16]} />
        <meshStandardMaterial color="#222" metalness={0.6} roughness={0.4} />
      </mesh>
      <mesh
        position={[-0.8, -0.2, -0.7]}
        rotation={[Math.PI / 2, 0, Math.PI / 2]}
      >
        <cylinderGeometry args={[0.3, 0.3, 0.15, 16]} />
        <meshStandardMaterial color="#222" metalness={0.6} roughness={0.4} />
      </mesh>
      <mesh
        position={[0.8, -0.2, -0.7]}
        rotation={[Math.PI / 2, 0, Math.PI / 2]}
      >
        <cylinderGeometry args={[0.3, 0.3, 0.15, 16]} />
        <meshStandardMaterial color="#222" metalness={0.6} roughness={0.4} />
      </mesh>

      {/* Camera with glowing lens */}
      <mesh position={[0, 0.4, -1.0]}>
        <boxGeometry args={[0.4, 0.4, 0.15]} />
        <meshStandardMaterial color="#111" />
      </mesh>
      <mesh position={[0, 0.4, -1.08]}>
        <circleGeometry args={[0.12, 16]} />
        <meshStandardMaterial emissive="#33C3F0" emissiveIntensity={2} />
      </mesh>

      {/* Ultrasonic walls */}
      {/* Front wall: moves only along Z-axis */}
      <mesh position={[0, 0, frontWallZ]}>
        <boxGeometry args={[8, 3, 0.1]} />
        <meshStandardMaterial
          color={getFillColor(frontDistance)}
          transparent={true}
          opacity={getOpacity(frontDistance)}
          side={THREE.DoubleSide}
        />
      </mesh>

      {/* Left wall: moves only along X-axis */}
      <mesh position={[leftWallX, 0, 0]} rotation={[0, Math.PI / 2, 0]}>
        <boxGeometry args={[8, 3, 0.1]} />
        <meshStandardMaterial
          color={getFillColor(leftDistance)}
          transparent={true}
          opacity={getOpacity(leftDistance)}
          side={THREE.DoubleSide}
        />
      </mesh>

      {/* Right wall: moves only along X-axis */}
      <mesh position={[rightWallX, 0, 0]} rotation={[0, Math.PI / 2, 0]}>
        <boxGeometry args={[8, 3, 0.1]} />
        <meshStandardMaterial
          color={getFillColor(rightDistance)}
          transparent={true}
          opacity={getOpacity(rightDistance)}
          side={THREE.DoubleSide}
        />
      </mesh>

      <pointLight position={[0, 0.6, 0]} intensity={0.5} color="#33C3F0" />
    </group>
  );
};

const BotCanvas = ({ rotation, ultrasonic }: BotCanvasProps) => {
  return (
    <Canvas
      camera={{ position: [3, 3, 3], fov: 50 }}
      style={{ width: "100%", height: "100%" }}
    >
      <color attach="background" args={["#f0f9ff"]} />
      <ambientLight intensity={0.6} />
      <directionalLight position={[5, 5, 5]} intensity={0.8} color="#ffffff" />
      <RobotModel rotation={rotation} ultrasonic={ultrasonic} />
      <gridHelper
        args={[20, 20, "#33C3F0", "#a5d8ff"]}
        position={[0, -0.5, 0]}
      />
      <OrbitControls enableZoom={true} enablePan={true} />
    </Canvas>
  );
};

export default BotCanvas;
