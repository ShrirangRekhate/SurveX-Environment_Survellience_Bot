import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import {
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Square,
  Gauge,
} from "lucide-react";

interface ControlPanelProps {
  connected: boolean;
  onSendCommand: (command: string, value?: number) => void;
  currentSpeed: number;
}

const ControlPanel = ({
  connected,
  onSendCommand,
  currentSpeed,
}: ControlPanelProps) => {
  const [speed, setSpeed] = useState(currentSpeed);
  const [activeButton, setActiveButton] = useState<string | null>(null);

  // Update local speed when prop changes
  useEffect(() => {
    setSpeed(currentSpeed);
  }, [currentSpeed]);

  const handleDirectionClick = (direction: string) => {
    if (!connected) return;
    setActiveButton(direction);
    onSendCommand(
      "move",
      direction === "stop"
        ? 0
        : direction === "forward"
        ? 1
        : direction === "backward"
        ? 2
        : direction === "left"
        ? 3
        : 4
    );
  };

  const handleSpeedChange = (newValue: number[]) => {
    const speedValue = newValue[0];
    setSpeed(speedValue);
    onSendCommand("speed", speedValue);
  };

  // Keyboard control handlers
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!connected) return;

      switch (e.key) {
        case "ArrowUp":
          handleDirectionClick("forward");
          break;
        case "ArrowDown":
          handleDirectionClick("backward");
          break;
        case "ArrowLeft":
          handleDirectionClick("left");
          break;
        case "ArrowRight":
          handleDirectionClick("right");
          break;
        case " ": // Space key
          handleDirectionClick("stop");
          break;
        default:
          break;
      }
    };

    const handleKeyUp = () => {
      setActiveButton(null);
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, [connected]);

  const getButtonClass = (direction: string) => {
    const baseClass = "control-btn shadow-lg transition-all duration-200";
    const activeClass = activeButton === direction ? "ring-4 ring-sky-300" : "";

    if (direction === "stop") {
      return `${baseClass} ${activeClass} bg-red-500 hover:bg-red-600 disabled:bg-gray-300 disabled:cursor-not-allowed text-white p-3 rounded-md`;
    }

    return `${baseClass} ${activeClass} bg-sky-500 hover:bg-sky-600 disabled:bg-gray-300 disabled:cursor-not-allowed text-white p-3 rounded-md`;
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <h2 className="text-lg font-semibold mb-4 text-sky-800">Bot Controls</h2>

      {/* Keyboard controls info */}
      <div className="text-sm text-sky-700 bg-sky-50 p-2 rounded-md mb-4 border border-sky-200">
        <p>Use keyboard arrows for movement, space to stop</p>
      </div>

      {/* Speed control - 0-255 range */}
      <div className="mb-6">
        <div className="flex items-center mb-2 text-sky-800">
          <Gauge className="w-4 h-4 mr-2" />
          <span>Speed: {speed}</span>
        </div>
        <Slider
          disabled={!connected}
          value={[speed]}
          min={0}
          max={255}
          step={5}
          onValueChange={handleSpeedChange}
          className="mb-6"
        />
      </div>

      {/* Direction controls */}
      <div className="grid grid-cols-3 gap-3 justify-items-center mb-2">
        <div className="col-start-2">
          <button
            className={getButtonClass("forward")}
            onClick={() => handleDirectionClick("forward")}
            disabled={!connected}
            title="Forward (Up Arrow)"
          >
            <ArrowUp className="w-6 h-6" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3 justify-items-center mb-2">
        <div>
          <button
            className={getButtonClass("left")}
            onClick={() => handleDirectionClick("left")}
            disabled={!connected}
            title="Left (Left Arrow)"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
        </div>
        <div>
          <button
            className={getButtonClass("stop")}
            onClick={() => handleDirectionClick("stop")}
            disabled={!connected}
            title="Stop (Space)"
          >
            <Square className="w-6 h-6" />
          </button>
        </div>
        <div>
          <button
            className={getButtonClass("right")}
            onClick={() => handleDirectionClick("right")}
            disabled={!connected}
            title="Right (Right Arrow)"
          >
            <ArrowRight className="w-6 h-6" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3 justify-items-center">
        <div className="col-start-2">
          <button
            className={getButtonClass("backward")}
            onClick={() => handleDirectionClick("backward")}
            disabled={!connected}
            title="Backward (Down Arrow)"
          >
            <ArrowDown className="w-6 h-6" />
          </button>
        </div>
      </div>

      <div className="mt-4 text-center text-sm text-sky-700">
        {!connected && "Connect to the bot to enable controls"}
      </div>
    </div>
  );
};

export default ControlPanel;
