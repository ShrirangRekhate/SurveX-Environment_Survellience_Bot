import React from "react";

interface DashboardProps {
  children: React.ReactNode;
}

const Dashboard = ({ children }: DashboardProps) => {
  return (
    <main className="flex-1 overflow-auto pb-4 bg-gradient-to-b from-sky-100 to-white">
      <div className="container mx-auto max-w-[1400px]">{children}</div>
    </main>
  );
};

export default Dashboard;
