import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { DEFAULT_ESP32_IP } from "@/lib/websocket";

interface NavbarProps {
  connected: boolean;
  onConnectClick: () => void;
  onConnect: (ipAddress: string) => void;
  connectionModalOpen: boolean;
  setConnectionModalOpen: (open: boolean) => void;
  connectionStatus: "connecting" | "connected" | "disconnected";
}

const Navbar = ({
  connected,
  onConnectClick,
  onConnect,
  connectionModalOpen,
  setConnectionModalOpen,
  connectionStatus,
}: NavbarProps) => {
  const [ipAddress, setIpAddress] = useState(DEFAULT_ESP32_IP);

  const handleConnect = () => {
    onConnect(ipAddress);
  };

  const getStatusDisplay = () => {
    switch (connectionStatus) {
      case "connecting":
        return (
          <>
            <div className="h-3 w-3 rounded-full bg-yellow-500 animate-pulse"></div>
            <span className="ml-2 text-sm font-medium text-yellow-600">
              Connecting...
            </span>
          </>
        );
      case "connected":
        return (
          <>
            <div className="h-3 w-3 rounded-full bg-green-500"></div>
            <span className="ml-2 text-sm font-medium text-green-600">
              Connected
            </span>
          </>
        );
      case "disconnected":
      default:
        return (
          <>
            <div className="h-3 w-3 rounded-full bg-red-500"></div>
            <span className="ml-2 text-sm font-medium text-red-600">
              Disconnected
            </span>
          </>
        );
    }
  };

  return (
    <nav className="bg-white shadow-md py-4 px-6 flex justify-between items-center">
      <div className="flex items-center">
        <h1 className="text-2xl font-bold text-sky-700">
          Environment Surveillance Bot
        </h1>
      </div>

      <div className="flex items-center space-x-2">
        <div className="flex items-center gap-2">{getStatusDisplay()}</div>
        <Button
          variant={connected ? "outline" : "default"}
          onClick={onConnectClick}
          size="sm"
          className={
            connected
              ? "bg-white text-sky-700 border-sky-500"
              : "bg-sky-500 hover:bg-sky-600"
          }
        >
          {connected ? "Disconnect" : "Connect"}
        </Button>
      </div>

      <Dialog open={connectionModalOpen} onOpenChange={setConnectionModalOpen}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle className="text-sky-800">
              Connect to Environment Surveillance Bot
            </DialogTitle>
            <DialogDescription>
              Enter the IP address of your ESP32 device to establish a WebSocket
              connection.
            </DialogDescription>
          </DialogHeader>

          <div className="py-4">
            <Input
              placeholder="192.168.1.x"
              value={ipAddress}
              onChange={(e) => setIpAddress(e.target.value)}
              className="border-sky-200 focus:border-sky-500"
            />
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setConnectionModalOpen(false)}
              className="border-sky-200"
            >
              Cancel
            </Button>
            <Button
              onClick={handleConnect}
              className="bg-sky-500 hover:bg-sky-600"
            >
              Connect
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </nav>
  );
};

export default Navbar;
