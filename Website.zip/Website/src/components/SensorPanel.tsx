import React from "react";
import { Progress } from "@/components/ui/progress";
import { Thermometer, Droplet, CloudOff, Fuel } from "lucide-react";

interface SensorPanelProps {
  temperature: number;
  humidity: number;
  smoke: number;
  lpgGas: number;
  coGas: number;
  ultrasonicFront: number;
  ultrasonicLeft: number;
  ultrasonicRight: number;
}

const SensorPanel = ({
  temperature,
  humidity,
  smoke,
  lpgGas,
  coGas,
  ultrasonicFront,
  ultrasonicLeft,
  ultrasonicRight,
}: SensorPanelProps) => {
  // Helper function to determine sensor status colors
  const getTemperatureColor = (temp: number) => {
    if (temp > 50) return "text-rescue-red";
    if (temp > 35) return "text-rescue-yellow";
    return "text-rescue-blue";
  };

  const getHumidityColor = (level: number) => {
    if (level > 80) return "text-rescue-blue";
    if (level > 40) return "text-green-500";
    return "text-rescue-yellow";
  };

  const getSmokeColor = (level: number) => {
    if (level > 70) return "text-rescue-red";
    if (level > 30) return "text-rescue-yellow";
    return "text-green-500";
  };

  const getGasColor = (level: number) => {
    if (level > 70) return "text-rescue-red";
    if (level > 30) return "text-rescue-yellow";
    return "text-green-500";
  };

  const getDistanceColor = (distance: number) => {
    if (distance < 10) return "bg-rescue-red";
    if (distance < 30) return "bg-rescue-yellow";
    return "bg-green-500";
  };

  return (
    <div className="sensor-panel bg-gradient-to-br from-card to-background/80 backdrop-blur-sm">
      <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
        <div className="bg-rescue-blue p-1 rounded-md">
          <Thermometer className="w-5 h-5 text-white" />
        </div>
        Sensor Readings
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Temperature */}
        <div className="p-3 border rounded-md bg-card/50 hover:bg-card/80 transition-colors">
          <div className="flex justify-between mb-1">
            <span className="text-sm flex items-center gap-1">
              <Thermometer className="w-4 h-4" />
              Temperature
            </span>
            <span
              className={`value-display ${getTemperatureColor(temperature)}`}
            >
              {temperature}°C
            </span>
          </div>
          <Progress value={temperature} max={100} className="h-2" />
        </div>

        {/* Humidity */}
        <div className="p-3 border rounded-md bg-card/50 hover:bg-card/80 transition-colors">
          <div className="flex justify-between mb-1">
            <span className="text-sm flex items-center gap-1">
              <Droplet className="w-4 h-4" />
              Humidity
            </span>
            <span className={`value-display ${getHumidityColor(humidity)}`}>
              {humidity}%
            </span>
          </div>
          <Progress value={humidity} max={100} className="h-2" />
        </div>

        {/* LPG Gas */}
        <div className="p-3 border rounded-md bg-card/50 hover:bg-card/80 transition-colors">
          <div className="flex justify-between mb-1">
            <span className="text-sm flex items-center gap-1">
              <Fuel className="w-4 h-4" />
              LPG Gas
            </span>
            <span className={`value-display ${getGasColor(lpgGas)}`}>
              {lpgGas}%
            </span>
          </div>
          <Progress value={lpgGas} max={100} className="h-2" />
        </div>

        {/* CO Gas */}
        <div className="p-3 border rounded-md bg-card/50 hover:bg-card/80 transition-colors">
          <div className="flex justify-between mb-1">
            <span className="text-sm flex items-center gap-1">
              <CloudOff className="w-4 h-4" />
              CO Gas
            </span>
            <span className={`value-display ${getGasColor(coGas)}`}>
              {coGas}%
            </span>
          </div>
          <Progress value={coGas} max={100} className="h-2" />
        </div>

        {/* Smoke */}
        <div className="p-3 border rounded-md bg-card/50 hover:bg-card/80 transition-colors md:col-span-2 lg:col-span-4">
          <div className="flex justify-between mb-1">
            <span className="text-sm">Smoke Level</span>
            <span className={`value-display ${getSmokeColor(smoke)}`}>
              {smoke}%
            </span>
          </div>
          <Progress value={smoke} max={200} className="h-2" />
        </div>

        {/* Ultrasonic Sensors */}
        <div className="p-3 border rounded-md bg-card/50 hover:bg-card/80 transition-colors md:col-span-2 lg:col-span-4">
          <span className="text-sm block mb-2">
            Ultrasonic Sensors (distance in cm)
          </span>

          <div className="grid grid-cols-3 gap-2 text-center">
            <div>
              <span className="text-sm">Left</span>
              <div className="mt-1 relative h-10">
                <div
                  className={`absolute inset-0 rounded ${getDistanceColor(
                    ultrasonicLeft
                  )}`}
                  style={{ width: `${Math.min(200, ultrasonicLeft / 2)}%` }}
                ></div>
                <div className="absolute inset-0 flex items-center justify-start pl-2">
                  <span className="font-semibold text-sm text-white">
                    {ultrasonicLeft}
                  </span>
                </div>
              </div>
            </div>

            <div>
              <span className="text-sm">Front</span>
              <div className="mt-1 relative h-10">
                <div
                  className={`absolute inset-0 rounded ${getDistanceColor(
                    ultrasonicFront
                  )}`}
                  style={{ width: `${Math.min(200, ultrasonicFront / 2)}%` }}
                ></div>
                <div className="absolute inset-0 flex items-center justify-start pl-2">
                  <span className="font-semibold text-sm text-white">
                    {ultrasonicFront}
                  </span>
                </div>
              </div>
            </div>

            <div>
              <span className="text-sm">Right</span>
              <div className="mt-1 relative h-10">
                <div
                  className={`absolute inset-0 rounded ${getDistanceColor(
                    ultrasonicRight
                  )}`}
                  style={{ width: `${Math.min(100, ultrasonicRight / 2)}%` }}
                ></div>
                <div className="absolute inset-0 flex items-center justify-start pl-2">
                  <span className="font-semibold text-sm text-white">
                    {ultrasonicRight}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SensorPanel;
