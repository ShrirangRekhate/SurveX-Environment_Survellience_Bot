import React from "react";

interface UltrasonicDisplayProps {
  front: number;
  left: number;
  right: number;
}

const UltrasonicDisplay: React.FC<UltrasonicDisplayProps> = ({
  front,
  left,
  right,
}) => {
  // Calculate wall positions based on distances (0-200cm range)
  const maxDistance = 200; // maximum detectable distance in cm

  // Calculate percentages for wall positions (closer = further from center)
  const frontWallPosition =
    (Math.min(Math.max(front, 5), maxDistance) / maxDistance) * 100;
  const leftWallPosition =
    (Math.min(Math.max(left, 5), maxDistance) / maxDistance) * 100;
  const rightWallPosition =
    (Math.min(Math.max(right, 5), maxDistance) / maxDistance) * 100;

  // Determine color intensity based on distance (closer = more intense red)
  const getFillColor = (distance: number) => {
    // If distance is less than 20cm, make it bright red
    if (distance < 20) return "rgba(255, 0, 0, 0.8)";
    // If distance is between 20cm and 50cm, make it medium red
    if (distance < 50) return "rgba(255, 0, 0, 0.5)";
    // If distance is greater than 50cm, make it light red
    return "rgba(255, 0, 0, 0.3)";
  };

  return (
    <div className="relative w-full h-40 bg-sky-50 border border-sky-200 rounded-lg overflow-hidden">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-20 h-20 bg-sky-500 rounded-full z-10 flex items-center justify-center">
          <span className="text-white font-bold">BOT</span>
        </div>
      </div>

      {/* Front Wall */}
      <div
        className="absolute top-0 left-0 right-0 bg-gradient-to-b from-transparent"
        style={{
          height: `${frontWallPosition}%`,
          backgroundColor: getFillColor(front),
          transition: "all 0.3s ease-out",
        }}
      >
        <div className="absolute bottom-0 w-full text-center text-xs font-medium text-white bg-black/30 py-1">
          {front}cm
        </div>
      </div>

      {/* Left Wall */}
      <div
        className="absolute top-0 left-0 bottom-0 bg-gradient-to-r from-transparent"
        style={{
          width: `${leftWallPosition}%`,
          backgroundColor: getFillColor(left),
          transition: "all 0.3s ease-out",
        }}
      >
        <div className="absolute right-0 h-full flex items-center">
          <div className="transform -rotate-90 origin-center text-xs font-medium text-white bg-black/30 px-2 py-1">
            {left}cm
          </div>
        </div>
      </div>

      {/* Right Wall */}
      <div
        className="absolute top-0 right-0 bottom-0 bg-gradient-to-l from-transparent"
        style={{
          width: `${rightWallPosition}%`,
          backgroundColor: getFillColor(right),
          transition: "all 0.3s ease-out",
        }}
      >
        <div className="absolute left-0 h-full flex items-center">
          <div className="transform rotate-90 origin-center text-xs font-medium text-white bg-black/30 px-2 py-1">
            {right}cm
          </div>
        </div>
      </div>
    </div>
  );
};

export default UltrasonicDisplay;
