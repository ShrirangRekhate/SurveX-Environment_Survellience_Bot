import React, { useState, useEffect } from "react";

interface VideoFeedProps {
  connected: boolean;
}

const VideoFeed = ({ connected }: VideoFeedProps) => {
  const [videoUrl, setVideoUrl] = useState<string | null>(null);

  // In a real implementation, you would set the video URL based on the ESP32 IP
  useEffect(() => {
    if (connected) {
      // This would normally be something like:
      // setVideoUrl(`http://${ipAddress}:81/stream`);
      // But for demo purposes, we'll use a placeholder
      setVideoUrl(null);
    } else {
      setVideoUrl(null);
    }
  }, [connected]);

  return (
    <div className="video-feed h-60 bg-gradient-to-br from-black/80 to-blue-900/30 backdrop-blur-sm rounded-lg flex items-center justify-center shadow-lg border border-blue-500/40">
      {videoUrl ? (
        <img
          src={videoUrl}
          alt="Bot camera feed"
          className="h-full w-full object-contain"
        />
      ) : (
        <div className="text-center p-4">
          <div className="text-blue-400 mb-2">
            {connected
              ? "Camera feed not available"
              : "Connect to the bot to view camera feed"}
          </div>
          <div className="w-16 h-16 rounded-full bg-blue-900/30 mx-auto flex items-center justify-center animate-pulse-glow">
            <div className="w-10 h-10 rounded-full bg-blue-700/30"></div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VideoFeed;
