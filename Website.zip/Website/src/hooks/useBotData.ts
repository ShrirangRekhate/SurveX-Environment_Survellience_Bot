import { useState } from "react";

export interface BotData {
  temperature: number;
  humidity: number;
  smoke: number;
  lpgGas: number;
  coGas: number;
  ultrasonic: {
    front: number;
    left: number;
    right: number;
  };
  orientation: {
    x: number;
    y: number;
    z: number;
  };
  speed: number;
}

export const useBotData = () => {
  // Initialize with default values
  const [botData, setBotData] = useState<BotData>({
    temperature: 25,
    humidity: 45,
    smoke: 0,
    lpgGas: 0,
    coGas: 0,
    ultrasonic: {
      front: 200,
      left: 200,
      right: 200,
    },
    orientation: {
      x: 0,
      y: 0,
      z: 0,
    },
    speed: 100, // Default speed (0-255)
  });

  // Update all bot data
  const updateBotData = (data: Partial<BotData>) => {
    setBotData((prev) => ({
      ...prev,
      ...data,
    }));
  };

  // Update just one sensor value
  const updateSensor = (sensorType: keyof BotData, value: any) => {
    setBotData((prev) => ({
      ...prev,
      [sensorType]: value,
    }));
  };

  // Reset to default values
  const resetBotData = () => {
    setBotData({
      temperature: 25,
      humidity: 45,
      smoke: 0,
      lpgGas: 0,
      coGas: 0,
      ultrasonic: {
        front: 200,
        left: 200,
        right: 200,
      },
      orientation: {
        x: 0,
        y: 0,
        z: 0,
      },
      speed: 100, // Default speed (0-255)
    });
  };

  return {
    botData,
    updateBotData,
    updateSensor,
    resetBotData,
  };
};
