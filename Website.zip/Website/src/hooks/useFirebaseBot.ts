import { useState, useEffect, useCallback } from "react";
import { useToast } from "@/components/ui/use-toast";
import { subscribeToPath, writeToPath } from "@/lib/firebase";
import { BotData } from "./useBotData";

export const useFirebaseBot = () => {
  const [connected, setConnected] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<
    "connecting" | "connected" | "disconnected"
  >("disconnected");
  const { toast } = useToast();
  const [lastUpdateCallback, setLastUpdateCallback] = useState<
    ((data: Partial<BotData>) => void) | null
  >(null);

  // Set the callback for updating botData
  const setUpdateCallback = useCallback(
    (callback: (data: Partial<BotData>) => void) => {
      setLastUpdateCallback(() => callback);
    },
    []
  );

  // Connect to Firebase
  const connect = useCallback(() => {
    try {
      setConnectionStatus("connecting");

      toast({
        title: "Connecting",
        description: "Trying to connect to the Environment Surveillance Bot...",
      });

      // Check if the bot is online by reading a timestamp
      const pingCheck = subscribeToPath("/sensors", (data) => {
        if (data) {
          setConnected(true);
          setConnectionStatus("connected");

          // If we have sensor data and a callback is set
          if (lastUpdateCallback && typeof lastUpdateCallback === "function") {
            // Extract and transform the sensor data to match our app's format
            const sensorData: Partial<BotData> = {
              temperature: data.dht?.temperatureC || 25,
              humidity: data.dht?.humidity || 45,
              smoke: data.mq2?.smoke || 0,
              lpgGas: data.mq2?.lpg || 0,
              coGas: data.mq2?.co || 0,
              ultrasonic: {
                front: data.ultrasonic?.front || 100,
                left: data.ultrasonic?.left || 100,
                right: data.ultrasonic?.right || 100,
              },
              orientation: {
                x: data.mpu?.angleX || 0,
                y: data.mpu?.angleY || 0,
                z: data.mpu?.angleZ || 0,
              },
            };
            lastUpdateCallback(sensorData);
          }

          toast({
            title: "Connected",
            description:
              "Successfully connected to the Environment Surveillance Bot",
          });
        }
      });

      return () => {
        pingCheck(); // Unsubscribe
        setConnected(false);
        setConnectionStatus("disconnected");
      };
    } catch (error) {
      setConnected(false);
      setConnectionStatus("disconnected");
      toast({
        title: "Connection Error",
        description: "Failed to connect to the Environment Surveillance Bot",
        variant: "destructive",
      });
      console.error("Firebase connection error:", error);
      return () => {}; // Return empty cleanup function
    }
  }, [toast, lastUpdateCallback]);

  // Disconnect
  const disconnect = useCallback(() => {
    setConnected(false);
    setConnectionStatus("disconnected");
    toast({
      title: "Disconnected",
      description: "Connection to the Environment Surveillance Bot closed",
    });
  }, [toast]);

  // Send command to the bot
  const sendCommand = useCallback(
    (command: string, value?: number) => {
      if (connected) {
        try {
          if (command === "move") {
            const direction =
              value === 0
                ? "stop"
                : value === 1
                ? "forward"
                : value === 2
                ? "backward"
                : value === 3
                ? "left"
                : "right";

            writeToPath("/control/direction", direction)
              .then(() =>
                console.log(`Sent command: ${command}, direction: ${direction}`)
              )
              .catch((error) => {
                console.error("Error sending command:", error);
                toast({
                  title: "Command Failed",
                  description: "Failed to send command to the bot",
                  variant: "destructive",
                });
              });
          } else if (command === "speed") {
            if (value !== undefined) {
              writeToPath("/control/speed", value)
                .then(() =>
                  console.log(`Sent command: ${command}, value: ${value}`)
                )
                .catch((error) => {
                  console.error("Error sending command:", error);
                  toast({
                    title: "Command Failed",
                    description: "Failed to set speed",
                    variant: "destructive",
                  });
                });
            }
          }
        } catch (error) {
          console.error("Error sending command:", error);
          toast({
            title: "Command Failed",
            description: "Error sending command to the bot",
            variant: "destructive",
          });
        }
      } else {
        console.warn("Cannot send command: Not connected to Firebase");
        toast({
          title: "Command Failed",
          description: "Cannot send command: Not connected to the bot",
          variant: "destructive",
        });
      }
    },
    [connected, toast]
  );

  return {
    connected,
    connectionStatus,
    connect,
    disconnect,
    sendCommand,
    setUpdateCallback,
  };
};
