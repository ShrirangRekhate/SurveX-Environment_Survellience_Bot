import { useState, useEffect, useCallback, useRef } from "react";
import { useToast } from "@/components/ui/use-toast";
import { BotData } from "./useBotData";
import {
  parseJsonSafely,
  DEFAULT_ESP32_IP,
  createWebSocketUrl,
} from "@/lib/websocket";

export const useWebSocket = () => {
  const [connected, setConnected] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<
    "connecting" | "connected" | "disconnected"
  >("disconnected");
  const [socketUrl, setSocketUrl] = useState<string | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const { toast } = useToast();
  const [lastUpdateCallback, setLastUpdateCallback] = useState<
    ((data: Partial<BotData>) => void) | null
  >(null);

  // Set the callback for updating botData
  const setUpdateCallback = useCallback(
    (callback: (data: Partial<BotData>) => void) => {
      setLastUpdateCallback(() => callback);
    },
    []
  );

  // Connect to WebSocket
  const connect = useCallback(
    (ip: string = DEFAULT_ESP32_IP) => {
      // Clean up existing connection if any
      if (socketRef.current) {
        socketRef.current.close();
        socketRef.current = null;
      }

      setConnectionStatus("connecting");

      try {
        // Create direct WebSocket connection
        const wsUrl = createWebSocketUrl(ip);
        console.log(`Connecting to WebSocket at ${wsUrl}`);

        const socket = new WebSocket(wsUrl);

        socket.onopen = () => {
          setConnected(true);
          setSocketUrl(ip);
          setConnectionStatus("connected");
          console.log("Connected to ESP32 WebSocket");
          toast({
            title: "Connected",
            description:
              "Successfully connected to the Environment Surveillance Bot",
          });
        };

        socket.onmessage = (event) => {
          try {
            const sensorData = parseJsonSafely(event.data);
            console.log("Sensor data received:", sensorData);

            if (!sensorData) return;

            // Transform ESP32 data format to our BotData format
            const transformedData: Partial<BotData> = {
              temperature: sensorData.dht?.tempC || 0,
              humidity: sensorData.dht?.humidity || 0,
              smoke: sensorData.mq2?.smoke || 0,
              lpgGas: sensorData.mq2?.lpg || 0,
              coGas: sensorData.mq2?.co || 0,
              ultrasonic: {
                front: sensorData.ultrasonic?.front || 0,
                left: sensorData.ultrasonic?.left || 0,
                right: sensorData.ultrasonic?.right || 0,
              },
              orientation: {
                x: sensorData.mpu?.angleX || 0,
                y: sensorData.mpu?.angleY || 0,
                z: sensorData.mpu?.angleZ || 0,
              },
            };

            // Update bot data if callback is set
            if (
              lastUpdateCallback &&
              typeof lastUpdateCallback === "function"
            ) {
              lastUpdateCallback(transformedData);
            }
          } catch (err) {
            console.error("Error parsing WebSocket message:", err);
          }
        };

        socket.onerror = (error) => {
          console.error("WebSocket error:", error);
          setConnected(false);
          setConnectionStatus("disconnected");
          toast({
            title: "Connection Error",
            description:
              "Failed to connect to the Environment Surveillance Bot",
            variant: "destructive",
          });
        };

        socket.onclose = (event) => {
          setConnected(false);
          setConnectionStatus("disconnected");
          console.log("WebSocket connection closed:", event);

          toast({
            title: "Disconnected",
            description:
              "Connection to the Environment Surveillance Bot closed",
            variant: "destructive",
          });
        };

        socketRef.current = socket;
        return socket;
      } catch (error) {
        setConnectionStatus("disconnected");
        toast({
          title: "Connection Error",
          description: "Failed to establish WebSocket connection",
          variant: "destructive",
        });
        console.error("WebSocket connection error:", error);
        return null;
      }
    },
    [toast, lastUpdateCallback]
  );

  // Disconnect from WebSocket
  const disconnect = useCallback(() => {
    if (socketRef.current) {
      socketRef.current.close();
      socketRef.current = null;
    }
    setConnected(false);
    setSocketUrl(null);
    setConnectionStatus("disconnected");
  }, []);

  // Send command to the bot - simplified to directly send the command string
  const sendCommand = useCallback(
    (command: string, value?: number) => {
      if (
        socketRef.current &&
        socketRef.current.readyState === WebSocket.OPEN
      ) {
        let cmdToSend;

        // Format the message according to ESP32 expectations
        if (command === "move") {
          // Map move values directly to ESP32 commands
          const moveCommands = ["stop", "forward", "backward", "left", "right"];
          cmdToSend = moveCommands[value || 0];
        } else if (command === "speed") {
          cmdToSend = `speed:${value}`;
        }

        if (cmdToSend) {
          socketRef.current.send(cmdToSend);
          console.log(`Sent command: ${cmdToSend}`);
        }
      } else {
        console.warn(
          "Cannot send command: WebSocket not connected or not ready"
        );
        toast({
          title: "Command Failed",
          description: "Cannot send command: Not connected to the bot",
          variant: "destructive",
        });
      }
    },
    [connected, toast]
  );

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (socketRef.current) {
        socketRef.current.close();
        socketRef.current = null;
      }
    };
  }, []);

  return {
    connected,
    connectionStatus,
    socketUrl,
    connect,
    disconnect,
    sendCommand,
    setUpdateCallback,
  };
};
