/**
 * ESP32 Integration Guide
 *
 * This file contains instructions and examples for integrating
 * your ESP32 with the rescue bot dashboard.
 */

/**
 * WebSocket Protocol:
 *
 * The dashboard and ESP32 communicate via WebSockets.
 * The ESP32 should host a WebSocket server at ws://[ESP32_IP]:81/ws
 *
 * Message Format (JSON):
 *
 * From Dashboard to ESP32:
 * Command format:
 * - For movement: "forward", "backward", "left", "right", "stop"
 * - For speed: "speed:100" (speed value from 0-255)
 *
 * From ESP32 to Dashboard:
 * {
 *   "mpu": {
 *     "angleX": 0.00,    // MPU6050 angle in degrees
 *     "angleY": 5.20,
 *     "angleZ": 0.00
 *   },
 *   "mq2": {
 *     "lpg": 15.5,       // LPG gas level
 *     "co": 12.3,        // CO gas level
 *     "smoke": 18.7      // Smoke level
 *   },
 *   "dht": {
 *     "tempC": 25.5,     // Temperature in Celsius
 *     "tempF": 77.9,     // Temperature in Fahrenheit
 *     "humidity": 45     // Humidity percentage
 *   },
 *   "ultrasonic": {      // Ultrasonic sensor readings in cm
 *     "front": 35,
 *     "left": 50,
 *     "right": 42
 *   }
 * }
 */

/**
 * ESP32 Arduino Code Example:
 *
 * Include these libraries:
 * - WiFi.h
 * - WebServer.h
 * - WebSocketsServer.h
 * - Wire.h
 * - MPU6050_tockn.h
 * - MQUnifiedsensor.h
 * - Bonezegei_DHT11.h
 *
 * Example code:
 * 
 * ```cpp
 * #include <WiFi.h>
 * #include <WebServer.h>
 * #include <WebSocketsServer.h>
 * #include <Wire.h>
 * #include <MPU6050_tockn.h>
 * #include <MQUnifiedsensor.h>
 * #include <Bonezegei_DHT11.h>
 * 
 * // WiFi credentials
 * #define WIFI_SSID "YourWiFiSSID"
 * #define WIFI_PASSWORD "YourWiFiPassword"
 * 
 * // WebSocket & HTTP Server
 * WebServer httpServer(80);
 * WebSocketsServer webSocket = WebSocketsServer(81);
 * 
 * // Sensors setup (as in your original code)
 * // Define sensor parameters
#define Board ("ESP32")
#define Voltage_Resolution 3.3
#define pinA0   36
#define pinDHT11 15

// Define the number of samples to calibrate
#define calibration_sample 50

// Define the pins used by the ultrasonic sensors
#define trigFront 27
#define echoFront 26
#define trigLeft 33
#define echoLeft 32
#define trigRight 25
#define echoRight 14

// Define motor control pins
#define motorPin1 12
#define motorPin2 13
#define motorPin3 4
#define motorPin4 5
#define motorSpeedPin 16

// Define variables for motor speed
int motorSpeed = 150;

// Create MPU6050 instance
MPU6050 mpu6050(Wire);

// Create DHT11 instance
DHT11 dht11(pinDHT11);

// Define the analog pin for the MQ2 sensor
#define MQ2_Analog_Pin pinA0

// Declare an object of the MQUnifiedsensor class
MQUnifiedsensor MQ2;

// Structure to hold MPU6050 data
struct MPUData {
  float angleX;
  float angleY;
  float angleZ;
};

// Structure to hold MQ2 sensor data
struct MQ2Data {
  float lpg;
  float co;
  float smoke;
};

// Structure to hold DHT11 sensor data
struct DHTData {
  float tempC;
  float tempF;
  int humidity;
};

// Function to initialize the MQ2 sensor
void initMQ2Sensor() {
  MQ2.setRegressionMethod(1); // Use linear regression
  MQ2.init();
  Serial.print("Calibrating please wait...");
  float calcR0 = 0;
  for (int i = 1; i <= calibration_sample; i++) {
    calcR0 += MQ2.calibrate(Voltage_Resolution, pinA0);
    Serial.print(".");
  }
  MQ2.R0 = calcR0 / calibration_sample;
  Serial.println(" done!");

  if (isinf(MQ2.R0)) {
    Serial.println("Warning: Conection issue, R0 is infinite (open circuit detected)");
    while (1) {
      delay(100);
    }
  }
  if (MQ2.R0 == 0) {
    Serial.println("Warning: Conection issue found, R0 is zero (short circuit detected)");
    while (1) {
      delay(100);
    }
  }
  MQ2.setR0(MQ2.R0);
}

// Function to read the MQ2 sensor values
MQ2Data readMQ2Sensor() {
  MQ2Data data;
  MQ2.update(); // Update data, read the voltage from the analog pin
  data.lpg = MQ2.readSensor(LPG);
  data.co = MQ2.readSensor(CO);
  data.smoke = MQ2.readSensor(SMOKE);
  return data;
}

// Function to get data from the MPU6050 sensor
MPUData getMPUData() {
  mpu6050.update();
  MPUData data;
  data.angleX = mpu6050.getAngleX();
  data.angleY = mpu6050.getAngleY();
  data.angleZ = mpu6050.getAngleZ();
  return data;
}

// Function to get data from the DHT11 sensor
DHTData getDHTData() {
  DHTData data;
  data.humidity = dht11.readHumidity();
  data.tempC = dht11.readTemperature();
  data.tempF = dht11.readTemperature(true);
  return data;
}

// Function to measure distance using ultrasonic sensor
long measureDistance(int trigPin, int echoPin) {
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  long duration = pulseIn(echoPin, HIGH);
  return duration / 29 / 2;
}

// Motor control functions
void motorForward() {
  digitalWrite(motorPin1, HIGH);
  digitalWrite(motorPin2, LOW);
  digitalWrite(motorPin3, HIGH);
  digitalWrite(motorPin4, LOW);
  analogWrite(motorSpeedPin, motorSpeed);
}

void motorBackward() {
  digitalWrite(motorPin1, LOW);
  digitalWrite(motorPin2, HIGH);
  digitalWrite(motorPin3, LOW);
  digitalWrite(motorPin4, HIGH);
  analogWrite(motorSpeedPin, motorSpeed);
}

void motorLeft() {
  digitalWrite(motorPin1, LOW);
  digitalWrite(motorPin2, HIGH);
  digitalWrite(motorPin3, HIGH);
  digitalWrite(motorPin4, LOW);
  analogWrite(motorSpeedPin, motorSpeed);
}

void motorRight() {
  digitalWrite(motorPin1, HIGH);
  digitalWrite(motorPin2, LOW);
  digitalWrite(motorPin3, LOW);
  digitalWrite(motorPin4, HIGH);
  analogWrite(motorSpeedPin, motorSpeed);
}

void motorStop() {
  digitalWrite(motorPin1, LOW);
  digitalWrite(motorPin2, LOW);
  digitalWrite(motorPin3, LOW);
  digitalWrite(motorPin4, LOW);
  analogWrite(motorSpeedPin, 0);
}
 * 
 * // WebSocket Event Handler - IMPORTANT TO UPDATE
 * void onWebSocketEvent(uint8_t client_num, WStype_t type, uint8_t * payload, size_t length) {
 *   switch (type) {
 *     case WStype_CONNECTED: {
 *       IPAddress ip = webSocket.remoteIP(client_num);
 *       Serial.printf("[%u] Connected from %s\n", client_num, ip.toString().c_str());
 *       webSocket.sendTXT(client_num, "Connected to ESP32!");
 *       break;
 *     }
 *     case WStype_TEXT: {
 *       String cmd = String((char*)payload).substring(0, length);
 *       Serial.printf("[%u] Received command: %s\n", client_num, cmd.c_str());
 *       
 *       // Process movement commands
 *       if (cmd == "forward") {
 *         motorForward();
 *       } else if (cmd == "backward") {
 *         motorBackward();
 *       } else if (cmd == "left") {
 *         motorLeft();
 *       } else if (cmd == "right") {
 *         motorRight();
 *       } else if (cmd == "stop") {
 *         motorStop();
 *       } else if (cmd.startsWith("speed:")) {
 *         // e.g., "speed:150" to set motorSpeed
 *         int newSpeed = cmd.substring(6).toInt();
 *         motorSpeed = newSpeed;
 *         Serial.printf("Motor speed set to: %d\n", motorSpeed);
 *       }
 *       break;
 *     }
 *     case WStype_DISCONNECTED: {
 *       Serial.printf("[%u] Disconnected\n", client_num);
 *       motorStop(); // Safety: stop motors when client disconnects
 *       break;
 *     }
 *     default:
 *       break;
 *   }
 * }
 * 
 * void setup() {
 *   // Initialize serial communication
  Serial.begin(115200);

  // Initialize the MPU6050 sensor
  Wire.begin();
  mpu6050.begin();
  mpu6050.calcGyroOffsets(true);

  // Initialize the MQ2 sensor
  initMQ2Sensor();

  // Setup ultrasonic sensor pins
  pinMode(trigFront, OUTPUT);
  pinMode(echoFront, INPUT);
  pinMode(trigLeft, OUTPUT);
  pinMode(echoLeft, INPUT);
  pinMode(trigRight, OUTPUT);
  pinMode(echoRight, INPUT);

  // Setup motor control pins
  pinMode(motorPin1, OUTPUT);
  pinMode(motorPin2, OUTPUT);
  pinMode(motorPin3, OUTPUT);
  pinMode(motorPin4, OUTPUT);
  pinMode(motorSpeedPin, OUTPUT);

  // Initialize WiFi
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connecting to WiFi...");
  }
  Serial.println("Connected to WiFi");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());
   
 *   // Setup WebSocket server
 *   webSocket.begin();
 *   webSocket.onEvent(onWebSocketEvent);
 *   
 *   // Start HTTP server
  httpServer.begin();
  Serial.println("HTTP server started");
 }
 * 
 * void loop() {
 *   httpServer.handleClient();
 *   webSocket.loop();
 *   
 *   // Send sensor updates periodically
 *   static unsigned long lastSendTime = 0;
 *   if (millis() - lastSendTime > 1000) { // every 1 second
 *     lastSendTime = millis();
 *     
 *     // Get sensor data
 *     MPUData mpuData = getMPUData();
 *     MQ2Data mq2Data = readMQ2Sensor();
 *     DHTData dhtData = getDHTData();
 *     long distFront = measureDistance(trigFront, echoFront);
 *     long distLeft = measureDistance(trigLeft, echoLeft);
 *     long distRight = measureDistance(trigRight, echoRight);
 *     
 *     // Format JSON exactly as the frontend expects
 *     String json = "{";
 *     json += "\"mpu\":{\"angleX\":" + String(mpuData.angleX, 2) + 
 *             ",\"angleY\":" + String(mpuData.angleY, 2) + 
 *             ",\"angleZ\":" + String(mpuData.angleZ, 2) + "},";
 *     json += "\"mq2\":{\"lpg\":" + String(mq2Data.lpg, 2) +
 *             ",\"co\":" + String(mq2Data.co, 2) +
 *             ",\"smoke\":" + String(mq2Data.smoke, 2) + "},";
 *     json += "\"dht\":{\"tempC\":" + String(dhtData.tempC, 2) +
 *             ",\"tempF\":" + String(dhtData.tempF, 2) +
 *             ",\"humidity\":" + String(dhtData.humidity) + "},";
 *     json += "\"ultrasonic\":{\"front\":" + String(distFront) +
 *             ",\"left\":" + String(distLeft) +
 *             ",\"right\":" + String(distRight) + "}";
 *     json += "}";
 *     
 *     // Send to all connected clients
 *     webSocket.broadcastTXT(json);
 *   }
 * }
 * 
// Function to initialize the MQ2 sensor
void initMQ2Sensor() {
  MQ2.setRegressionMethod(1); // Use linear regression
  MQ2.init();
  Serial.print("Calibrating please wait...");
  float calcR0 = 0;
  for (int i = 1; i <= calibration_sample; i++) {
    calcR0 += MQ2.calibrate(Voltage_Resolution, pinA0);
    Serial.print(".");
  }
  MQ2.R0 = calcR0 / calibration_sample;
  Serial.println(" done!");

  if (isinf(MQ2.R0)) {
    Serial.println("Warning: Conection issue, R0 is infinite (open circuit detected)");
    while (1) {
      delay(100);
    }
  }
  if (MQ2.R0 == 0) {
    Serial.println("Warning: Conection issue found, R0 is zero (short circuit detected)");
    while (1) {
      delay(100);
    }
  }
  MQ2.setR0(MQ2.R0);
}

// Function to read the MQ2 sensor values
MQ2Data readMQ2Sensor() {
  MQ2Data data;
  MQ2.update(); // Update data, read the voltage from the analog pin
  data.lpg = MQ2.readSensor(LPG);
  data.co = MQ2.readSensor(CO);
  data.smoke = MQ2.readSensor(SMOKE);
  return data;
}

// Function to get data from the MPU6050 sensor
MPUData getMPUData() {
  mpu6050.update();
  MPUData data;
  data.angleX = mpu6050.getAngleX();
  data.angleY = mpu6050.getAngleY();
  data.angleZ = mpu6050.getAngleZ();
  return data;
}

// Function to get data from the DHT11 sensor
DHTData getDHTData() {
  DHTData data;
  data.humidity = dht11.readHumidity();
  data.tempC = dht11.readTemperature();
  data.tempF = dht11.readTemperature(true);
  return data;
}

// Function to measure distance using ultrasonic sensor
long measureDistance(int trigPin, int echoPin) {
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  long duration = pulseIn(echoPin, HIGH);
  return duration / 29 / 2;
}

// Motor control functions
void motorForward() {
  digitalWrite(motorPin1, HIGH);
  digitalWrite(motorPin2, LOW);
  digitalWrite(motorPin3, HIGH);
  digitalWrite(motorPin4, LOW);
  analogWrite(motorSpeedPin, motorSpeed);
}

void motorBackward() {
  digitalWrite(motorPin1, LOW);
  digitalWrite(motorPin2, HIGH);
  digitalWrite(motorPin3, LOW);
  digitalWrite(motorPin4, HIGH);
  analogWrite(motorSpeedPin, motorSpeed);
}

void motorLeft() {
  digitalWrite(motorPin1, LOW);
  digitalWrite(motorPin2, HIGH);
  digitalWrite(motorPin3, HIGH);
  digitalWrite(motorPin4, LOW);
  analogWrite(motorSpeedPin, motorSpeed);
}

void motorRight() {
  digitalWrite(motorPin1, HIGH);
  digitalWrite(motorPin2, LOW);
  digitalWrite(motorPin3, LOW);
  digitalWrite(motorPin4, HIGH);
  analogWrite(motorSpeedPin, motorSpeed);
}

void motorStop() {
  digitalWrite(motorPin1, LOW);
  digitalWrite(motorPin2, LOW);
  digitalWrite(motorPin3, LOW);
  digitalWrite(motorPin4, LOW);
  analogWrite(motorSpeedPin, 0);
}
 * ```
 */

/**
 * Important Notes:
 *
 * 1. Make sure the WebSocketsServer is on port 81 (webSocket = WebSocketsServer(81))
 * 2. The frontend expects movement commands as simple strings: "forward", "backward", etc.
 * 3. Speed commands are sent as "speed:X" where X is 0-255
 * 4. The JSON data format must match exactly what the frontend expects
 * 5. The ultrasonic measurements should be in centimeters
 */

export const ESP32_INTEGRATION_GUIDE =
  "See file for ESP32 integration instructions";
