import { initializeApp } from "firebase/app";
import {
  getDatabase,
  ref,
  onValue,
  set,
  off,
  DatabaseReference,
} from "firebase/database";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCDSwURE1yZsPZyIHJZpETk0DyUJMEIgTY",
  databaseURL:
    "https://rescue-bot-d49b8-default-rtdb.asia-southeast1.firebasedatabase.app/",
  projectId: "rescue-bot-d49b8",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

// Export functions to interact with Firebase
export const getFirebaseRef = (path: string): DatabaseReference => {
  return ref(database, path);
};

export const subscribeToPath = (
  path: string,
  callback: (data: any) => void
): (() => void) => {
  const dbRef = ref(database, path);

  onValue(dbRef, (snapshot) => {
    const data = snapshot.val();
    callback(data);
  });

  // Return unsubscribe function
  return () => off(dbRef);
};

export const writeToPath = (path: string, value: any): Promise<void> => {
  const dbRef = ref(database, path);
  return set(dbRef, value);
};

export default { getFirebaseRef, subscribeToPath, writeToPath };
