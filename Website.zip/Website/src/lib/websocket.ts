/**
 * WebSocket utilities for ESP32 integration
 */

// Default ESP32 IP address
export const DEFAULT_ESP32_IP = "192.168.117.213";

// Helper function to create WebSocket URL
export const createWebSocketUrl = (ip: string = DEFAULT_ESP32_IP) => {
  return `ws://${ip}:81`;
};

// Helper function to parse JSON safely
export const parseJsonSafely = (jsonString: string) => {
  try {
    return JSON.parse(jsonString);
  } catch (error) {
    console.error("Failed to parse JSON:", error);
    return null;
  }
};

// Format commands to send to ESP32
export const formatMovementCommand = (direction: number): string => {
  switch (direction) {
    case 0:
      return "stop";
    case 1:
      return "forward";
    case 2:
      return "backward";
    case 3:
      return "left";
    case 4:
      return "right";
    default:
      return "stop";
  }
};

export const formatSpeedCommand = (speed: number): string => {
  return `speed:${speed}`;
};
