import React, { useState, useEffect } from "react";
import { useToast } from "@/components/ui/use-toast";
import Dashboard from "@/components/Dashboard";
import BotCanvas from "@/components/BotCanvas";
import ControlPanel from "@/components/ControlPanel";
import { useBotData } from "@/hooks/useBotData";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useIsMobile } from "@/hooks/use-mobile";
import Navbar from "@/components/Navbar";
import { DEFAULT_ESP32_IP } from "@/lib/websocket";

const Index = () => {
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const {
    connected,
    connectionStatus,
    connect,
    disconnect,
    sendCommand,
    setUpdateCallback,
  } = useWebSocket();

  const { botData, updateBotData, resetBotData } = useBotData();

  // Connection state
  const [connectionModalOpen, setConnectionModalOpen] = useState(false);

  // Set the update callback to update bot data when WebSocket receives data
  useEffect(() => {
    setUpdateCallback(updateBotData);
  }, [setUpdateCallback, updateBotData]);

  // Auto-connect on component mount
  useEffect(() => {
    // Uncomment to auto-connect on page load
    // connect(DEFAULT_ESP32_IP);
  }, []);

  // Handle connection to ESP32
  const handleConnect = (ipAddress: string = DEFAULT_ESP32_IP) => {
    if (!ipAddress) {
      toast({
        title: "Error",
        description: "Please enter a valid IP address",
        variant: "destructive",
      });
      return;
    }

    connect(ipAddress);
    setConnectionModalOpen(false);
  };

  const handleConnectClick = () => {
    if (connected) {
      disconnect();
    } else {
      setConnectionModalOpen(true);
    }
  };

  // Handle keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!connected) return;

      switch (e.key.toLowerCase()) {
        case "w":
        case "arrowup":
          sendCommand("move", 1); // Forward
          break;
        case "s":
        case "arrowdown":
          sendCommand("move", 2); // Backward
          break;
        case "a":
        case "arrowleft":
          sendCommand("move", 3); // Left
          break;
        case "d":
        case "arrowright":
          sendCommand("move", 4); // Right
          break;
        case " ":
          sendCommand("move", 0); // Stop
          break;
        default:
          break;
      }
    };

    window.addEventListener("keydown", handleKeyDown);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [connected, sendCommand]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-100 via-white to-sky-100 flex flex-col">
      <Navbar
        connected={connected}
        onConnectClick={handleConnectClick}
        onConnect={handleConnect}
        connectionModalOpen={connectionModalOpen}
        setConnectionModalOpen={setConnectionModalOpen}
        connectionStatus={connectionStatus}
      />

      <Dashboard>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 p-4">
          <div className="lg:col-span-8 space-y-4">
            {/* 3D Bot visualization (now includes ultrasonic visualization) */}
            <div className="h-[500px] bg-white rounded-lg shadow-md overflow-hidden">
              <div className="text-lg font-bold mb-2 text-sky-700 px-4 pt-2 flex items-center">
                <div className="w-3 h-3 rounded-full bg-sky-500 mr-2 animate-pulse"></div>
                <h2>Bot Visualization</h2>
              </div>
              <BotCanvas
                rotation={botData.orientation}
                ultrasonic={botData.ultrasonic}
              />
            </div>

            {/* Controls section */}
            <div className="p-4 bg-white rounded-lg shadow-md">
              <ControlPanel
                connected={connected}
                onSendCommand={sendCommand}
                currentSpeed={botData.speed}
              />
            </div>
          </div>

          {/* Right column - Sensor readings */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-white rounded-lg shadow-md p-3 h-full animate-fade-in">
              <div className="text-lg font-bold mb-3 text-sky-700 flex items-center">
                <div className="w-3 h-3 rounded-full bg-sky-500 mr-2 animate-pulse"></div>
                Environment Data
              </div>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="p-2 bg-sky-50 rounded-md border border-sky-200">
                  <div className="text-xs text-sky-700">Temperature</div>
                  <div className="text-xl font-bold text-sky-900">
                    {botData.temperature}°C
                  </div>
                </div>
                <div className="p-2 bg-sky-50 rounded-md border border-sky-200">
                  <div className="text-xs text-sky-700">Humidity</div>
                  <div className="text-xl font-bold text-sky-900">
                    {botData.humidity}%
                  </div>
                </div>
                <div className="p-2 bg-sky-50 rounded-md border border-sky-200">
                  <div className="text-xs text-sky-700">LPG Gas</div>
                  <div className="text-xl font-bold text-sky-900">
                    {botData.lpgGas}%
                  </div>
                </div>
                <div className="p-2 bg-sky-50 rounded-md border border-sky-200">
                  <div className="text-xs text-sky-700">CO Gas</div>
                  <div className="text-xl font-bold text-sky-900">
                    {botData.coGas}%
                  </div>
                </div>
                <div className="p-2 bg-sky-50 rounded-md col-span-2 border border-sky-200">
                  <div className="text-xs text-sky-700">Smoke Level</div>
                  <div className="text-xl font-bold text-sky-900">
                    {botData.smoke}%
                  </div>
                </div>
              </div>

              <h3 className="text-sm font-semibold mt-4 mb-2 text-sky-700 flex items-center">
                <div className="w-2 h-2 rounded-full bg-sky-500 mr-2"></div>
                Distance Readings (cm)
              </h3>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="p-2 bg-sky-50 rounded-md border border-sky-200">
                  <div className="text-xs text-sky-700">Left</div>
                  <div className="text-lg font-bold text-sky-900">
                    {botData.ultrasonic.left}
                  </div>
                </div>
                <div className="p-2 bg-sky-50 rounded-md border border-sky-200">
                  <div className="text-xs text-sky-700">Front</div>
                  <div className="text-lg font-bold text-sky-900">
                    {botData.ultrasonic.front}
                  </div>
                </div>
                <div className="p-2 bg-sky-50 rounded-md border border-sky-200">
                  <div className="text-xs text-sky-700">Right</div>
                  <div className="text-lg font-bold text-sky-900">
                    {botData.ultrasonic.right}
                  </div>
                </div>
              </div>

              {/* Show connection status */}
              <div
                className={`mt-6 p-2 rounded-lg text-center border ${
                  connected
                    ? "bg-green-50 border-green-200"
                    : "bg-red-50 border-red-200"
                }`}
              >
                <div className="flex items-center justify-center space-x-2">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      connected ? "bg-green-500 animate-ping" : "bg-red-500"
                    }`}
                  ></div>
                  <span
                    className={`text-sm font-medium ${
                      connected ? "text-green-600" : "text-red-600"
                    }`}
                  >
                    {connected ? "Connected" : "Disconnected"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Dashboard>
    </div>
  );
};

export default Index;
